/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.registry;

import org.jetbrains.annotations.ApiStatus;

import java.util.Collection;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;

@ApiStatus.NonExtendable
@ApiStatus.Experimental
public interface CreativeTabOutput extends ItemGroup.Entries {
    void acceptAfter(ItemStack after, ItemStack stack, ItemGroup.StackVisibility visibility);
    
    void acceptBefore(ItemStack before, ItemStack stack, ItemGroup.StackVisibility visibility);
    
    @Override
    default void add(ItemStack stack, ItemGroup.StackVisibility visibility) {
        acceptAfter(ItemStack.EMPTY, stack, visibility);
    }
    
    default void acceptAfter(ItemStack after, ItemStack stack) {
        this.acceptAfter(after, stack, ItemGroup.StackVisibility.PARENT_AND_SEARCH_TABS);
    }
    
    default void acceptAfter(ItemStack after, ItemConvertible item, ItemGroup.StackVisibility visibility) {
        this.acceptAfter(after, new ItemStack(item), visibility);
    }
    
    default void acceptAfter(ItemStack after, ItemConvertible item) {
        this.acceptAfter(after, new ItemStack(item), ItemGroup.StackVisibility.PARENT_AND_SEARCH_TABS);
    }
    
    default void acceptAllAfter(ItemStack after, Collection<ItemStack> stacks, ItemGroup.StackVisibility visibility) {
        stacks.forEach((stack) -> acceptAfter(after, stack, visibility));
    }
    
    default void acceptAllAfter(ItemStack after, Collection<ItemStack> stacks) {
        this.acceptAllAfter(after, stacks, ItemGroup.StackVisibility.PARENT_AND_SEARCH_TABS);
    }
    
    default void acceptAfter(ItemConvertible after, ItemStack stack) {
        this.acceptAfter(new ItemStack(after), stack);
    }
    
    default void acceptAfter(ItemConvertible after, ItemConvertible item, ItemGroup.StackVisibility visibility) {
        this.acceptAfter(new ItemStack(after), item, visibility);
    }
    
    default void acceptAfter(ItemConvertible after, ItemConvertible item) {
        this.acceptAfter(new ItemStack(after), item);
    }
    
    default void acceptAllAfter(ItemConvertible after, Collection<ItemStack> stacks, ItemGroup.StackVisibility visibility) {
        acceptAllAfter(new ItemStack(after), stacks, visibility);
    }
    
    default void acceptAllAfter(ItemConvertible after, Collection<ItemStack> stacks) {
        acceptAllAfter(new ItemStack(after), stacks);
    }
    
    default void acceptBefore(ItemStack before, ItemStack stack) {
        this.acceptBefore(before, stack, ItemGroup.StackVisibility.PARENT_AND_SEARCH_TABS);
    }
    
    default void acceptBefore(ItemStack before, ItemConvertible item, ItemGroup.StackVisibility visibility) {
        this.acceptBefore(before, new ItemStack(item), visibility);
    }
    
    default void acceptBefore(ItemStack before, ItemConvertible item) {
        this.acceptBefore(before, new ItemStack(item), ItemGroup.StackVisibility.PARENT_AND_SEARCH_TABS);
    }
    
    default void acceptAllBefore(ItemStack before, Collection<ItemStack> stacks, ItemGroup.StackVisibility visibility) {
        stacks.forEach((stack) -> acceptBefore(before, stack, visibility));
    }
    
    default void acceptAllBefore(ItemStack before, Collection<ItemStack> stacks) {
        this.acceptAllBefore(before, stacks, ItemGroup.StackVisibility.PARENT_AND_SEARCH_TABS);
    }
    
    default void acceptBefore(ItemConvertible before, ItemStack stack) {
        this.acceptBefore(new ItemStack(before), stack);
    }
    
    default void acceptBefore(ItemConvertible before, ItemConvertible item, ItemGroup.StackVisibility visibility) {
        this.acceptBefore(new ItemStack(before), item, visibility);
    }
    
    default void acceptBefore(ItemConvertible before, ItemConvertible item) {
        this.acceptBefore(new ItemStack(before), item);
    }
    
    default void acceptAllBefore(ItemConvertible before, Collection<ItemStack> stacks, ItemGroup.StackVisibility visibility) {
        acceptAllBefore(new ItemStack(before), stacks, visibility);
    }
    
    default void acceptAllBefore(ItemConvertible before, Collection<ItemStack> stacks) {
        acceptAllBefore(new ItemStack(before), stacks);
    }
}
