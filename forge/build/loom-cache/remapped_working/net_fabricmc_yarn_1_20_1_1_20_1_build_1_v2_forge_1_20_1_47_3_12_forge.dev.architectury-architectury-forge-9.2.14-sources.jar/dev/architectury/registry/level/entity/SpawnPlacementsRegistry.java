/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.registry.level.entity;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.function.Supplier;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.world.Heightmap;

public final class SpawnPlacementsRegistry {
    /**
     * Registers the spawn placement of an entity.
     *
     * @param type           the type of entity
     * @param spawnPlacement the type of spawn placement
     * @param heightmapType  the type of heightmap
     * @param spawnPredicate the spawn predicate
     * @see net.minecraft.entity.SpawnRestriction
     */
    @ExpectPlatform
    public static <T extends MobEntity> void register(Supplier<? extends EntityType<T>> type, SpawnRestriction.Location spawnPlacement, Heightmap.Type heightmapType, SpawnRestriction.SpawnPredicate<T> spawnPredicate) {
        throw new AssertionError();
    }
}
