package net.minecraft.data.server.loottable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.IntStream;
import net.fabricmc.fabric.api.datagen.v1.loot.FabricBlockLootTableGenerator;
import net.minecraft.block.BeehiveBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.CandleBlock;
import net.minecraft.block.CaveVines;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FlowerPotBlock;
import net.minecraft.block.FlowerbedBlock;
import net.minecraft.block.MultifaceGrowthBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StemBlock;
import net.minecraft.block.TallPlantBlock;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.Items;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.LootTables;
import net.minecraft.loot.condition.BlockStatePropertyLootCondition;
import net.minecraft.loot.condition.LocationCheckLootCondition;
import net.minecraft.loot.condition.LootConditionConsumingBuilder;
import net.minecraft.loot.condition.MatchToolLootCondition;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.condition.SurvivesExplosionLootCondition;
import net.minecraft.loot.condition.TableBonusLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.entry.LootPoolEntry.Builder;
import net.minecraft.loot.function.ApplyBonusLootFunction;
import net.minecraft.loot.function.CopyComponentsLootFunction;
import net.minecraft.loot.function.CopyStateLootFunction;
import net.minecraft.loot.function.ExplosionDecayLootFunction;
import net.minecraft.loot.function.LimitCountLootFunction;
import net.minecraft.loot.function.LootFunctionConsumingBuilder;
import net.minecraft.loot.function.SetCountLootFunction;
import net.minecraft.loot.function.CopyComponentsLootFunction.Source;
import net.minecraft.loot.operator.BoundedIntUnaryOperator;
import net.minecraft.loot.provider.number.BinomialLootNumberProvider;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.loot.provider.number.LootNumberProvider;
import net.minecraft.loot.provider.number.UniformLootNumberProvider;
import net.minecraft.predicate.NumberRange.IntRange;
import net.minecraft.predicate.item.EnchantmentPredicate;
import net.minecraft.predicate.item.EnchantmentsPredicate;
import net.minecraft.predicate.item.ItemSubPredicateTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper.Impl;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.state.property.Property;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public abstract class BlockLootTableGenerator implements LootTableGenerator, FabricBlockLootTableGenerator {
	public static final net.minecraft.loot.condition.LootCondition.Builder WITH_SHEARS = MatchToolLootCondition.builder(
		net.minecraft.predicate.item.ItemPredicate.Builder.create().items(Items.SHEARS)
	);
	protected final WrapperLookup registryLookup;
	protected final Set<Item> explosionImmuneItems;
	protected final FeatureSet requiredFeatures;
	protected final Map<RegistryKey<LootTable>, LootTable.Builder> lootTables;
	protected static final float[] SAPLING_DROP_CHANCE = new float[]{0.05F, 0.0625F, 0.083333336F, 0.1F};
	private static final float[] LEAVES_STICK_DROP_CHANCE = new float[]{0.02F, 0.022222223F, 0.025F, 0.033333335F, 0.1F};

	public net.minecraft.loot.condition.LootCondition.Builder createSilkTouchCondition() {
		Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
		return MatchToolLootCondition.builder(
			net.minecraft.predicate.item.ItemPredicate.Builder.create()
				.subPredicate(
					ItemSubPredicateTypes.ENCHANTMENTS,
					EnchantmentsPredicate.enchantments(List.of(new EnchantmentPredicate(impl.getOrThrow(Enchantments.SILK_TOUCH), IntRange.atLeast(1))))
				)
		);
	}

	public net.minecraft.loot.condition.LootCondition.Builder createWithoutSilkTouchCondition() {
		return this.createSilkTouchCondition().invert();
	}

	public final net.minecraft.loot.condition.LootCondition.Builder createWithShearsOrSilkTouchCondition() {
		return WITH_SHEARS.or(this.createSilkTouchCondition());
	}

	public final net.minecraft.loot.condition.LootCondition.Builder createWithoutShearsOrSilkTouchCondition() {
		return this.createWithShearsOrSilkTouchCondition().invert();
	}

	protected BlockLootTableGenerator(Set<Item> explosionImmuneItems, FeatureSet requiredFeatures, WrapperLookup registryLookup) {
		this(explosionImmuneItems, requiredFeatures, new HashMap(), registryLookup);
	}

	protected BlockLootTableGenerator(
		Set<Item> explosionImmuneItems, FeatureSet requiredFeatures, Map<RegistryKey<LootTable>, LootTable.Builder> lootTables, WrapperLookup registryLookup
	) {
		this.explosionImmuneItems = explosionImmuneItems;
		this.requiredFeatures = requiredFeatures;
		this.lootTables = lootTables;
		this.registryLookup = registryLookup;
	}

	public <T extends LootFunctionConsumingBuilder<T>> T applyExplosionDecay(ItemConvertible drop, LootFunctionConsumingBuilder<T> builder) {
		return !this.explosionImmuneItems.contains(drop.asItem()) ? builder.apply(ExplosionDecayLootFunction.builder()) : builder.getThisFunctionConsumingBuilder();
	}

	public <T extends LootConditionConsumingBuilder<T>> T addSurvivesExplosionCondition(ItemConvertible drop, LootConditionConsumingBuilder<T> builder) {
		return !this.explosionImmuneItems.contains(drop.asItem())
			? builder.conditionally(SurvivesExplosionLootCondition.builder())
			: builder.getThisConditionConsumingBuilder();
	}

	public LootTable.Builder drops(ItemConvertible drop) {
		return LootTable.builder()
			.pool(this.addSurvivesExplosionCondition(drop, LootPool.builder().rolls(ConstantLootNumberProvider.create(1.0F)).with(ItemEntry.builder(drop))));
	}

	public static LootTable.Builder drops(Block drop, net.minecraft.loot.condition.LootCondition.Builder conditionBuilder, Builder<?> child) {
		return LootTable.builder()
			.pool(LootPool.builder().rolls(ConstantLootNumberProvider.create(1.0F)).with(ItemEntry.builder(drop).conditionally(conditionBuilder).alternatively(child)));
	}

	public LootTable.Builder dropsWithSilkTouch(Block block, Builder<?> loot) {
		return drops(block, this.createSilkTouchCondition(), loot);
	}

	public LootTable.Builder dropsWithShears(Block block, Builder<?> loot) {
		return drops(block, WITH_SHEARS, loot);
	}

	public LootTable.Builder dropsWithSilkTouchOrShears(Block block, Builder<?> loot) {
		return drops(block, this.createWithShearsOrSilkTouchCondition(), loot);
	}

	public LootTable.Builder drops(Block withSilkTouch, ItemConvertible withoutSilkTouch) {
		return this.dropsWithSilkTouch(withSilkTouch, (Builder<?>)this.addSurvivesExplosionCondition(withSilkTouch, ItemEntry.builder(withoutSilkTouch)));
	}

	public LootTable.Builder drops(ItemConvertible drop, LootNumberProvider count) {
		return LootTable.builder()
			.pool(
				LootPool.builder()
					.rolls(ConstantLootNumberProvider.create(1.0F))
					.with((Builder<?>)this.applyExplosionDecay(drop, ItemEntry.builder(drop).apply(SetCountLootFunction.builder(count))))
			);
	}

	public LootTable.Builder drops(Block block, ItemConvertible drop, LootNumberProvider count) {
		return this.dropsWithSilkTouch(block, (Builder<?>)this.applyExplosionDecay(block, ItemEntry.builder(drop).apply(SetCountLootFunction.builder(count))));
	}

	public final LootTable.Builder dropsWithSilkTouch(ItemConvertible drop) {
		return LootTable.builder()
			.pool(LootPool.builder().conditionally(this.createSilkTouchCondition()).rolls(ConstantLootNumberProvider.create(1.0F)).with(ItemEntry.builder(drop)));
	}

	public final LootTable.Builder pottedPlantDrops(ItemConvertible drop) {
		return LootTable.builder()
			.pool(
				this.addSurvivesExplosionCondition(
					Blocks.FLOWER_POT, LootPool.builder().rolls(ConstantLootNumberProvider.create(1.0F)).with(ItemEntry.builder(Blocks.FLOWER_POT))
				)
			)
			.pool(this.addSurvivesExplosionCondition(drop, LootPool.builder().rolls(ConstantLootNumberProvider.create(1.0F)).with(ItemEntry.builder(drop))));
	}

	public LootTable.Builder slabDrops(Block drop) {
		return LootTable.builder()
			.pool(
				LootPool.builder()
					.rolls(ConstantLootNumberProvider.create(1.0F))
					.with(
						(Builder<?>)this.applyExplosionDecay(
							drop,
							ItemEntry.builder(drop)
								.apply(
									SetCountLootFunction.builder(ConstantLootNumberProvider.create(2.0F))
										.conditionally(
											BlockStatePropertyLootCondition.builder(drop)
												.properties(net.minecraft.predicate.StatePredicate.Builder.create().exactMatch(SlabBlock.TYPE, SlabType.DOUBLE))
										)
								)
						)
					)
			);
	}

	public <T extends Comparable<T> & StringIdentifiable> LootTable.Builder dropsWithProperty(Block drop, Property<T> property, T value) {
		return LootTable.builder()
			.pool(
				this.addSurvivesExplosionCondition(
					drop,
					LootPool.builder()
						.rolls(ConstantLootNumberProvider.create(1.0F))
						.with(
							ItemEntry.builder(drop)
								.conditionally(
									BlockStatePropertyLootCondition.builder(drop).properties(net.minecraft.predicate.StatePredicate.Builder.create().exactMatch(property, value))
								)
						)
				)
			);
	}

	public LootTable.Builder nameableContainerDrops(Block drop) {
		return LootTable.builder()
			.pool(
				this.addSurvivesExplosionCondition(
					drop,
					LootPool.builder()
						.rolls(ConstantLootNumberProvider.create(1.0F))
						.with(ItemEntry.builder(drop).apply(CopyComponentsLootFunction.builder(Source.BLOCK_ENTITY).include(DataComponentTypes.CUSTOM_NAME)))
				)
			);
	}

	public LootTable.Builder shulkerBoxDrops(Block drop) {
		return LootTable.builder()
			.pool(
				this.addSurvivesExplosionCondition(
					drop,
					LootPool.builder()
						.rolls(ConstantLootNumberProvider.create(1.0F))
						.with(
							ItemEntry.builder(drop)
								.apply(
									CopyComponentsLootFunction.builder(Source.BLOCK_ENTITY)
										.include(DataComponentTypes.CUSTOM_NAME)
										.include(DataComponentTypes.CONTAINER)
										.include(DataComponentTypes.LOCK)
										.include(DataComponentTypes.CONTAINER_LOOT)
								)
						)
				)
			);
	}

	public LootTable.Builder copperOreDrops(Block drop) {
		Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
		return this.dropsWithSilkTouch(
			drop,
			(Builder<?>)this.applyExplosionDecay(
				drop,
				ItemEntry.builder(Items.RAW_COPPER)
					.apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(2.0F, 5.0F)))
					.apply(ApplyBonusLootFunction.oreDrops(impl.getOrThrow(Enchantments.FORTUNE)))
			)
		);
	}

	public LootTable.Builder lapisOreDrops(Block drop) {
		Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
		return this.dropsWithSilkTouch(
			drop,
			(Builder<?>)this.applyExplosionDecay(
				drop,
				ItemEntry.builder(Items.LAPIS_LAZULI)
					.apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(4.0F, 9.0F)))
					.apply(ApplyBonusLootFunction.oreDrops(impl.getOrThrow(Enchantments.FORTUNE)))
			)
		);
	}

	public LootTable.Builder redstoneOreDrops(Block drop) {
		Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
		return this.dropsWithSilkTouch(
			drop,
			(Builder<?>)this.applyExplosionDecay(
				drop,
				ItemEntry.builder(Items.REDSTONE)
					.apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(4.0F, 5.0F)))
					.apply(ApplyBonusLootFunction.uniformBonusCount(impl.getOrThrow(Enchantments.FORTUNE)))
			)
		);
	}

	public LootTable.Builder bannerDrops(Block drop) {
		return LootTable.builder()
			.pool(
				this.addSurvivesExplosionCondition(
					drop,
					LootPool.builder()
						.rolls(ConstantLootNumberProvider.create(1.0F))
						.with(
							ItemEntry.builder(drop)
								.apply(
									CopyComponentsLootFunction.builder(Source.BLOCK_ENTITY)
										.include(DataComponentTypes.CUSTOM_NAME)
										.include(DataComponentTypes.ITEM_NAME)
										.include(DataComponentTypes.HIDE_ADDITIONAL_TOOLTIP)
										.include(DataComponentTypes.BANNER_PATTERNS)
								)
						)
				)
			);
	}

	public LootTable.Builder beeNestDrops(Block drop) {
		return LootTable.builder()
			.pool(
				LootPool.builder()
					.conditionally(this.createSilkTouchCondition())
					.rolls(ConstantLootNumberProvider.create(1.0F))
					.with(
						ItemEntry.builder(drop)
							.apply(CopyComponentsLootFunction.builder(Source.BLOCK_ENTITY).include(DataComponentTypes.BEES))
							.apply(CopyStateLootFunction.builder(drop).addProperty(BeehiveBlock.HONEY_LEVEL))
					)
			);
	}

	public LootTable.Builder beehiveDrops(Block drop) {
		return LootTable.builder()
			.pool(
				LootPool.builder()
					.rolls(ConstantLootNumberProvider.create(1.0F))
					.with(
						ItemEntry.builder(drop)
							.conditionally(this.createSilkTouchCondition())
							.apply(CopyComponentsLootFunction.builder(Source.BLOCK_ENTITY).include(DataComponentTypes.BEES))
							.apply(CopyStateLootFunction.builder(drop).addProperty(BeehiveBlock.HONEY_LEVEL))
							.alternatively(ItemEntry.builder(drop))
					)
			);
	}

	public LootTable.Builder glowBerryDrops(Block drop) {
		return LootTable.builder()
			.pool(
				LootPool.builder()
					.with(ItemEntry.builder(Items.GLOW_BERRIES))
					.conditionally(
						BlockStatePropertyLootCondition.builder(drop).properties(net.minecraft.predicate.StatePredicate.Builder.create().exactMatch(CaveVines.BERRIES, true))
					)
			);
	}

	public LootTable.Builder oreDrops(Block withSilkTouch, Item withoutSilkTouch) {
		Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
		return this.dropsWithSilkTouch(
			withSilkTouch,
			(Builder<?>)this.applyExplosionDecay(
				withSilkTouch, ItemEntry.builder(withoutSilkTouch).apply(ApplyBonusLootFunction.oreDrops(impl.getOrThrow(Enchantments.FORTUNE)))
			)
		);
	}

	public LootTable.Builder mushroomBlockDrops(Block withSilkTouch, ItemConvertible withoutSilkTouch) {
		return this.dropsWithSilkTouch(
			withSilkTouch,
			(Builder<?>)this.applyExplosionDecay(
				withSilkTouch,
				ItemEntry.builder(withoutSilkTouch)
					.apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(-6.0F, 2.0F)))
					.apply(LimitCountLootFunction.builder(BoundedIntUnaryOperator.createMin(0)))
			)
		);
	}

	public LootTable.Builder shortPlantDrops(Block withShears) {
		Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
		return this.dropsWithShears(
			withShears,
			(Builder<?>)this.applyExplosionDecay(
				withShears,
				ItemEntry.builder(Items.WHEAT_SEEDS)
					.conditionally(RandomChanceLootCondition.builder(0.125F))
					.apply(ApplyBonusLootFunction.uniformBonusCount(impl.getOrThrow(Enchantments.FORTUNE), 2))
			)
		);
	}

	public LootTable.Builder cropStemDrops(Block stem, Item drop) {
		return LootTable.builder()
			.pool(
				this.applyExplosionDecay(
					stem,
					LootPool.builder()
						.rolls(ConstantLootNumberProvider.create(1.0F))
						.with(
							ItemEntry.builder(drop)
								.apply(
									StemBlock.AGE.getValues(),
									age -> SetCountLootFunction.builder(BinomialLootNumberProvider.create(3, (float)(age + 1) / 15.0F))
											.conditionally(
												BlockStatePropertyLootCondition.builder(stem).properties(net.minecraft.predicate.StatePredicate.Builder.create().exactMatch(StemBlock.AGE, age))
											)
								)
						)
				)
			);
	}

	public LootTable.Builder attachedCropStemDrops(Block stem, Item drop) {
		return LootTable.builder()
			.pool(
				this.applyExplosionDecay(
					stem,
					LootPool.builder()
						.rolls(ConstantLootNumberProvider.create(1.0F))
						.with(ItemEntry.builder(drop).apply(SetCountLootFunction.builder(BinomialLootNumberProvider.create(3, 0.53333336F))))
				)
			);
	}

	public static LootTable.Builder dropsWithShears(ItemConvertible drop) {
		return LootTable.builder().pool(LootPool.builder().rolls(ConstantLootNumberProvider.create(1.0F)).conditionally(WITH_SHEARS).with(ItemEntry.builder(drop)));
	}

	public LootTable.Builder multifaceGrowthDrops(Block drop, net.minecraft.loot.condition.LootCondition.Builder condition) {
		return LootTable.builder()
			.pool(
				LootPool.builder()
					.with(
						(Builder<?>)this.applyExplosionDecay(
							drop,
							ItemEntry.builder(drop)
								.conditionally(condition)
								.apply(
									Direction.values(),
									direction -> SetCountLootFunction.builder(ConstantLootNumberProvider.create(1.0F), true)
											.conditionally(
												BlockStatePropertyLootCondition.builder(drop)
													.properties(net.minecraft.predicate.StatePredicate.Builder.create().exactMatch(MultifaceGrowthBlock.getProperty(direction), true))
											)
								)
								.apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(-1.0F), true))
						)
					)
			);
	}

	public LootTable.Builder leavesDrops(Block leaves, Block sapling, float... saplingChance) {
		Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
		return this.dropsWithSilkTouchOrShears(
				leaves,
				((net.minecraft.loot.entry.LeafEntry.Builder)this.addSurvivesExplosionCondition(leaves, ItemEntry.builder(sapling)))
					.conditionally(TableBonusLootCondition.builder(impl.getOrThrow(Enchantments.FORTUNE), saplingChance))
			)
			.pool(
				LootPool.builder()
					.rolls(ConstantLootNumberProvider.create(1.0F))
					.conditionally(this.createWithoutShearsOrSilkTouchCondition())
					.with(
						((net.minecraft.loot.entry.LeafEntry.Builder)this.applyExplosionDecay(
								leaves, ItemEntry.builder(Items.STICK).apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(1.0F, 2.0F)))
							))
							.conditionally(TableBonusLootCondition.builder(impl.getOrThrow(Enchantments.FORTUNE), LEAVES_STICK_DROP_CHANCE))
					)
			);
	}

	public LootTable.Builder oakLeavesDrops(Block leaves, Block sapling, float... saplingChance) {
		Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
		return this.leavesDrops(leaves, sapling, saplingChance)
			.pool(
				LootPool.builder()
					.rolls(ConstantLootNumberProvider.create(1.0F))
					.conditionally(this.createWithoutShearsOrSilkTouchCondition())
					.with(
						((net.minecraft.loot.entry.LeafEntry.Builder)this.addSurvivesExplosionCondition(leaves, ItemEntry.builder(Items.APPLE)))
							.conditionally(TableBonusLootCondition.builder(impl.getOrThrow(Enchantments.FORTUNE), 0.005F, 0.0055555557F, 0.00625F, 0.008333334F, 0.025F))
					)
			);
	}

	public LootTable.Builder mangroveLeavesDrops(Block leaves) {
		Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
		return this.dropsWithSilkTouchOrShears(
			leaves,
			((net.minecraft.loot.entry.LeafEntry.Builder)this.applyExplosionDecay(
					Blocks.MANGROVE_LEAVES, ItemEntry.builder(Items.STICK).apply(SetCountLootFunction.builder(UniformLootNumberProvider.create(1.0F, 2.0F)))
				))
				.conditionally(TableBonusLootCondition.builder(impl.getOrThrow(Enchantments.FORTUNE), LEAVES_STICK_DROP_CHANCE))
		);
	}

	public LootTable.Builder cropDrops(Block crop, Item product, Item seeds, net.minecraft.loot.condition.LootCondition.Builder condition) {
		Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
		return this.applyExplosionDecay(
			crop,
			LootTable.builder()
				.pool(LootPool.builder().with(ItemEntry.builder(product).conditionally(condition).alternatively(ItemEntry.builder(seeds))))
				.pool(
					LootPool.builder()
						.conditionally(condition)
						.with(ItemEntry.builder(seeds).apply(ApplyBonusLootFunction.binomialWithBonusCount(impl.getOrThrow(Enchantments.FORTUNE), 0.5714286F, 3)))
				)
		);
	}

	public LootTable.Builder seagrassDrops(Block seagrass) {
		return LootTable.builder()
			.pool(
				LootPool.builder()
					.conditionally(WITH_SHEARS)
					.with(ItemEntry.builder(seagrass).apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(2.0F))))
			);
	}

	public LootTable.Builder tallPlantDrops(Block tallPlant, Block shortPlant) {
		Builder<?> builder = ItemEntry.builder(shortPlant)
			.apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(2.0F)))
			.conditionally(WITH_SHEARS)
			.alternatively(
				((net.minecraft.loot.entry.LeafEntry.Builder)this.addSurvivesExplosionCondition(tallPlant, ItemEntry.builder(Items.WHEAT_SEEDS)))
					.conditionally(RandomChanceLootCondition.builder(0.125F))
			);
		return LootTable.builder()
			.pool(
				LootPool.builder()
					.with(builder)
					.conditionally(
						BlockStatePropertyLootCondition.builder(tallPlant)
							.properties(net.minecraft.predicate.StatePredicate.Builder.create().exactMatch(TallPlantBlock.HALF, DoubleBlockHalf.LOWER))
					)
					.conditionally(
						LocationCheckLootCondition.builder(
							net.minecraft.predicate.entity.LocationPredicate.Builder.create()
								.block(
									net.minecraft.predicate.BlockPredicate.Builder.create()
										.blocks(tallPlant)
										.state(net.minecraft.predicate.StatePredicate.Builder.create().exactMatch(TallPlantBlock.HALF, DoubleBlockHalf.UPPER))
								),
							new BlockPos(0, 1, 0)
						)
					)
			)
			.pool(
				LootPool.builder()
					.with(builder)
					.conditionally(
						BlockStatePropertyLootCondition.builder(tallPlant)
							.properties(net.minecraft.predicate.StatePredicate.Builder.create().exactMatch(TallPlantBlock.HALF, DoubleBlockHalf.UPPER))
					)
					.conditionally(
						LocationCheckLootCondition.builder(
							net.minecraft.predicate.entity.LocationPredicate.Builder.create()
								.block(
									net.minecraft.predicate.BlockPredicate.Builder.create()
										.blocks(tallPlant)
										.state(net.minecraft.predicate.StatePredicate.Builder.create().exactMatch(TallPlantBlock.HALF, DoubleBlockHalf.LOWER))
								),
							new BlockPos(0, -1, 0)
						)
					)
			);
	}

	public LootTable.Builder candleDrops(Block candle) {
		return LootTable.builder()
			.pool(
				LootPool.builder()
					.rolls(ConstantLootNumberProvider.create(1.0F))
					.with(
						(Builder<?>)this.applyExplosionDecay(
							candle,
							ItemEntry.builder(candle)
								.apply(
									List.of(2, 3, 4),
									candles -> SetCountLootFunction.builder(ConstantLootNumberProvider.create((float)candles.intValue()))
											.conditionally(
												BlockStatePropertyLootCondition.builder(candle)
													.properties(net.minecraft.predicate.StatePredicate.Builder.create().exactMatch(CandleBlock.CANDLES, candles))
											)
								)
						)
					)
			);
	}

	public LootTable.Builder flowerbedDrops(Block flowerbed) {
		return LootTable.builder()
			.pool(
				LootPool.builder()
					.rolls(ConstantLootNumberProvider.create(1.0F))
					.with(
						(Builder<?>)this.applyExplosionDecay(
							flowerbed,
							ItemEntry.builder(flowerbed)
								.apply(
									IntStream.rangeClosed(1, 4).boxed().toList(),
									flowerAmount -> SetCountLootFunction.builder(ConstantLootNumberProvider.create((float)flowerAmount.intValue()))
											.conditionally(
												BlockStatePropertyLootCondition.builder(flowerbed)
													.properties(net.minecraft.predicate.StatePredicate.Builder.create().exactMatch(FlowerbedBlock.FLOWER_AMOUNT, flowerAmount))
											)
								)
						)
					)
			);
	}

	public static LootTable.Builder candleCakeDrops(Block candleCake) {
		return LootTable.builder().pool(LootPool.builder().rolls(ConstantLootNumberProvider.create(1.0F)).with(ItemEntry.builder(candleCake)));
	}

	public static LootTable.Builder dropsNothing() {
		return LootTable.builder();
	}

	public abstract void generate();

	@Override
	public void accept(BiConsumer<RegistryKey<LootTable>, LootTable.Builder> lootTableBiConsumer) {
		this.generate();
		Set<RegistryKey<LootTable>> set = new HashSet();

		for (Block block : Registries.BLOCK) {
			if (block.isEnabled(this.requiredFeatures)) {
				RegistryKey<LootTable> registryKey = block.getLootTableKey();
				if (registryKey != LootTables.EMPTY && set.add(registryKey)) {
					LootTable.Builder builder = (LootTable.Builder)this.lootTables.remove(registryKey);
					if (builder == null) {
						throw new IllegalStateException(String.format(Locale.ROOT, "Missing loottable '%s' for '%s'", registryKey.getValue(), Registries.BLOCK.getId(block)));
					}

					lootTableBiConsumer.accept(registryKey, builder);
				}
			}
		}

		if (!this.lootTables.isEmpty()) {
			throw new IllegalStateException("Created block loot tables for non-blocks: " + this.lootTables.keySet());
		}
	}

	public void addVinePlantDrop(Block vine, Block vinePlant) {
		Impl<Enchantment> impl = this.registryLookup.getWrapperOrThrow(RegistryKeys.ENCHANTMENT);
		LootTable.Builder builder = this.dropsWithSilkTouchOrShears(
			vine, ItemEntry.builder(vine).conditionally(TableBonusLootCondition.builder(impl.getOrThrow(Enchantments.FORTUNE), 0.33F, 0.55F, 0.77F, 1.0F))
		);
		this.addDrop(vine, builder);
		this.addDrop(vinePlant, builder);
	}

	public LootTable.Builder doorDrops(Block block) {
		return this.dropsWithProperty(block, DoorBlock.HALF, DoubleBlockHalf.LOWER);
	}

	public void addPottedPlantDrops(Block block) {
		this.addDrop(block, flowerPot -> this.pottedPlantDrops(((FlowerPotBlock)flowerPot).getContent()));
	}

	public void addDropWithSilkTouch(Block block, Block drop) {
		this.addDrop(block, this.dropsWithSilkTouch(drop));
	}

	public void addDrop(Block block, ItemConvertible drop) {
		this.addDrop(block, this.drops(drop));
	}

	public void addDropWithSilkTouch(Block block) {
		this.addDropWithSilkTouch(block, block);
	}

	public void addDrop(Block block) {
		this.addDrop(block, block);
	}

	public void addDrop(Block block, Function<Block, LootTable.Builder> lootTableFunction) {
		this.addDrop(block, (LootTable.Builder)lootTableFunction.apply(block));
	}

	public void addDrop(Block block, LootTable.Builder lootTable) {
		this.lootTables.put(block.getLootTableKey(), lootTable);
	}
}
