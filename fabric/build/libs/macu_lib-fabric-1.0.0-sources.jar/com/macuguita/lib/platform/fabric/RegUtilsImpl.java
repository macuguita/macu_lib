package com.macuguita.lib.platform.fabric;

import com.macuguita.lib.MacuguitaLib;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class RegUtilsImpl {

    public static List<Supplier<class_2248>> REGISTERED_BLOCKS = new ArrayList<>();

    public static <T extends class_2248> Supplier<T> registerBlock(String name, Supplier<T> block) {
        var registry = class_2378.method_10230(class_7923.field_41175, new class_2960(MacuguitaLib.getModId(), name), block.get());
        REGISTERED_BLOCKS.add(() -> registry);
        return () -> registry;
    }
    public static <T extends class_1792> Supplier<T> registerItem(String name, Supplier<T> item) {
        var registry = class_2378.method_10230(class_7923.field_41178, new class_2960(MacuguitaLib.getModId(), name), item.get());
        return () -> registry;
    }
}
