/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.mixin.forge.neoforge;

import dev.architectury.event.forge.EventHandlerImplCommon;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.ChunkSerializer;
import net.minecraft.world.chunk.ProtoChunk;
import net.minecraft.world.poi.PointOfInterestStorage;
import net.minecraft.world.storage.StorageKey;
import net.neoforged.bus.api.Event;
import net.neoforged.neoforge.event.level.ChunkDataEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.lang.ref.WeakReference;

@Mixin(ChunkSerializer.class)
public class MixinChunkSerializer {
    @Unique
    private static ThreadLocal<WeakReference<ServerWorld>> level = new ThreadLocal<>();
    
    @Inject(method = "read", at = @At("HEAD"))
    private static void read(ServerWorld worldIn, PointOfInterestStorage arg2, StorageKey arg3, ChunkPos arg4, NbtCompound arg5, CallbackInfoReturnable<ProtoChunk> cir) {
        level.set(new WeakReference<>(worldIn));
    }
    
    @ModifyArg(method = "read", at = @At(value = "INVOKE",
            ordinal = 1,
            target = "Lnet/neoforged/bus/api/IEventBus;post(Lnet/neoforged/bus/api/Event;)Lnet/neoforged/bus/api/Event;"),
            index = 0)
    private static Event modifyProtoChunkLevel(Event event) {
        // We should get this PRed to Forge
        WeakReference<ServerWorld> levelRef = level.get();
        if (levelRef != null && event instanceof ChunkDataEvent.Load) {
            ChunkDataEvent.Load load = (ChunkDataEvent.Load) event;
            ((EventHandlerImplCommon.LevelEventAttachment) load).architectury$attachLevel(levelRef.get());
        }
        level.remove();
        return event;
    }
}
