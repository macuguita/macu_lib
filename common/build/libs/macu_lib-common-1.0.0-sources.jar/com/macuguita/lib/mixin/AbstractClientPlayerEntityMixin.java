package com.macuguita.lib.mixin;

import com.macuguita.lib.MacuguitaLib;
import com.macuguita.lib.supporters.RoleChecker;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Objects;
import net.minecraft.class_2960;
import net.minecraft.class_742;

@Mixin(class_742.class)
public class AbstractClientPlayerEntityMixin {

    // Path to the custom cape texture in the resources folder
    @Unique
    private static final class_2960 DEVELOPER_CAPE_TEXTURE = new class_2960(MacuguitaLib.MOD_ID, "textures/capes/developer_cape.png");

    @Inject(
            method = "getCapeTexture",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onGetCapeTexture(CallbackInfoReturnable<class_2960> cir) {
        // Cast 'this' to AbstractClientPlayerEntity
        class_742 player = (class_742) (Object) this;

        // Check if the player has the "developer" role
        if (Objects.equals(RoleChecker.getPlayerRole(player.method_5667()), "developer")) {
            // Return the custom cape texture
            cir.setReturnValue(DEVELOPER_CAPE_TEXTURE);
        }
    }
}