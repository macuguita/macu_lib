/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.mixin.forge;

import dev.architectury.event.events.client.ClientTickEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Supplier;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.profiler.Profiler;
import net.minecraft.world.MutableWorldProperties;
import net.minecraft.world.World;
import net.minecraft.world.dimension.DimensionType;

@Mixin(ClientWorld.class)
public abstract class MixinClientLevel extends World {
    protected MixinClientLevel(MutableWorldProperties arg, RegistryKey<World> arg2, DynamicRegistryManager arg3, RegistryEntry<DimensionType> arg4, Supplier<Profiler> supplier, boolean bl, boolean bl2, long l, int i) {
        super(arg, arg2, arg3, arg4, supplier, bl, bl2, l, i);
    }
    
    @Inject(method = "tickEntities", at = @At("HEAD"))
    private void tickEntities(CallbackInfo ci) {
        Profiler profiler = getProfiler();
        profiler.push("architecturyClientLevelPreTick");
        ClientTickEvent.CLIENT_LEVEL_PRE.invoker().tick((ClientWorld) (Object) this);
        profiler.pop();
    }
    
    @Inject(method = "tickEntities", at = @At("RETURN"))
    private void tickEntitiesPost(CallbackInfo ci) {
        Profiler profiler = getProfiler();
        profiler.push("architecturyClientLevelPostTick");
        ClientTickEvent.CLIENT_LEVEL_POST.invoker().tick((ClientWorld) (Object) this);
        profiler.pop();
    }
}
