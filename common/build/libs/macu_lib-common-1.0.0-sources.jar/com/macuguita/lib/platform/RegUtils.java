package com.macuguita.lib.platform;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_2248;

public class RegUtils {

    @ExpectPlatform
    public static <T extends class_2248> Supplier<T> registerBlock(String name, Supplier<T> block) {
        throw new AssertionError();
    }
    @ExpectPlatform
    public static <T extends class_1792> Supplier<T> registerItem(String name, Supplier<T> item) {
        throw new AssertionError();
    }
}