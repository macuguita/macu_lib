/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.fluid.fabric;

import I;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.architectury.fluid.FluidStack;
import io.netty.buffer.ByteBuf;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.minecraft.component.ComponentChanges;
import net.minecraft.component.ComponentMap;
import net.minecraft.component.ComponentMapImpl;
import net.minecraft.component.ComponentType;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

@ApiStatus.Internal
public enum FluidStackImpl implements FluidStack.FluidStackAdapter<FluidStackImpl.Pair> {
    INSTANCE;
    
    static {
        dev.architectury.fluid.FluidStack.init();
    }
    
    public static Function<FluidStack, Object> toValue;
    public static Function<Object, FluidStack> fromValue;
    
    public static FluidStack.FluidStackAdapter<Object> adapt(Function<FluidStack, Object> toValue, Function<Object, dev.architectury.fluid.FluidStack> fromValue) {
        FluidStackImpl.toValue = toValue;
        FluidStackImpl.fromValue = fromValue;
        return (FluidStack.FluidStackAdapter<Object>) (FluidStack.FluidStackAdapter<?>) INSTANCE;
    }
    
    public static class Pair {
        public Fluid fluid;
        public ComponentMapImpl components;
        public long amount;
        
        public Pair(Fluid fluid, @Nullable ComponentChanges patch, long amount) {
            this(fluid,
                    patch == null ? new ComponentMapImpl(ComponentMap.EMPTY)
                            : ComponentMapImpl.create(ComponentMap.EMPTY, patch),
                    amount);
        }
        
        public Pair(Fluid fluid, ComponentMapImpl components, long amount) {
            this.fluid = fluid;
            this.components = components;
            this.amount = amount;
        }
        
        public FluidVariant toVariant() {
            return FluidVariant.of(fluid, getPatch());
        }
        
        public ComponentChanges getPatch() {
            return amount <= 0L || this.fluid == Fluids.EMPTY ? components.getChanges() : ComponentChanges.EMPTY;
        }
    }
    
    @Override
    public FluidStackImpl.Pair create(Supplier<Fluid> fluid, long amount, @Nullable ComponentChanges patch) {
        Fluid fluidType = Objects.requireNonNull(fluid).get();
        if (fluidType instanceof FlowableFluid flowingFluid) {
            fluidType = flowingFluid.getStill();
        }
        return new Pair(fluidType, patch, amount);
    }
    
    @Override
    public Supplier<Fluid> getRawFluidSupplier(FluidStackImpl.Pair object) {
        return () -> object.fluid;
    }
    
    @Override
    public Fluid getFluid(FluidStackImpl.Pair object) {
        return object.fluid;
    }
    
    @Override
    public long getAmount(FluidStackImpl.Pair object) {
        return object.amount;
    }
    
    @Override
    public void setAmount(FluidStackImpl.Pair object, long amount) {
        object.amount = amount;
    }
    
    public ComponentChanges getPatch(FluidStackImpl.Pair value) {
        return value.getPatch();
    }
    
    @Override
    public ComponentMapImpl getComponents(Pair value) {
        return value.components;
    }
    
    @Override
    public void applyComponents(Pair value, ComponentChanges patch) {
        value.components.applyChanges(patch);
    }
    
    @Override
    public void applyComponents(Pair value, ComponentMap patch) {
        value.components.setAll(patch);
    }
    
    @Override
    @Nullable
    public <D> D set(Pair value, ComponentType<? super D> type, @Nullable D component) {
        return value.components.set(type, component);
    }
    
    @Override
    @Nullable
    public <D> D remove(Pair value, ComponentType<? extends D> type) {
        return value.components.remove(type);
    }
    
    @Override
    @Nullable
    public <D> D update(Pair value, ComponentType<D> type, D component, UnaryOperator<D> updater) {
        return value.components.set(type, updater.apply(getComponents(value).getOrDefault(type, component)));
    }
    
    @Override
    @Nullable
    public <D, U> D update(Pair value, ComponentType<D> type, D component, U updateContext, BiFunction<D, U, D> updater) {
        return value.components.set(type, updater.apply(getComponents(value).getOrDefault(type, component), updateContext));
    }
    
    @Override
    public FluidStackImpl.Pair copy(FluidStackImpl.Pair value) {
        return new Pair(value.fluid, value.components.copy(), value.amount);
    }
    
    @Override
    public int hashCode(FluidStackImpl.Pair value) {
        var pair = (Pair) value;
        var code = 1;
        code = 31 * code + pair.fluid.hashCode();
        code = 31 * code + Long.hashCode(pair.amount);
        code = 31 * code + pair.components.hashCode();
        return code;
    }
    
    @Override
    public Codec<FluidStack> codec() {
        return RecordCodecBuilder.create(instance -> instance.group(
                Registries.FLUID.getEntryCodec().fieldOf("fluid").forGetter(stack -> stack.getFluid().getRegistryEntry()),
                Codec.LONG.validate(value -> {
                    return value.compareTo(0L) >= 0 && value.compareTo(Long.MAX_VALUE) <= 0
                            ? DataResult.success(value)
                            : DataResult.error(() -> "Value must be non-negative: " + value);
                }).fieldOf("amount").forGetter(FluidStack::getAmount),
                ComponentChanges.CODEC.optionalFieldOf("components", ComponentChanges.EMPTY).forGetter(FluidStack::getPatch)
        ).apply(instance, FluidStack::create));
    }
    
    @Override
    public PacketCodec<RegistryByteBuf, FluidStack> streamCodec() {
        return PacketCodec.tuple(PacketCodecs.registryEntry(RegistryKeys.FLUID), stack -> stack.getFluid().getRegistryEntry(),
                PacketCodec.ofStatic(ByteBuf::writeLong, ByteBuf::readLong), FluidStack::getAmount,
                ComponentChanges.PACKET_CODEC, FluidStack::getPatch,
                FluidStack::create);
    }
}
