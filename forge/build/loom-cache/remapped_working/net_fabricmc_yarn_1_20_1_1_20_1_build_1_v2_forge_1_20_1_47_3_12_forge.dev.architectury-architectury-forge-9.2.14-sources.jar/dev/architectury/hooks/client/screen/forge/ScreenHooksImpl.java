/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.hooks.client.screen.forge;

import net.minecraft.client.gui.Drawable;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

public class ScreenHooksImpl {
    public static List<Selectable> getNarratables(Screen screen) {
        return screen.selectables;
    }
    
    public static List<Drawable> getRenderables(Screen screen) {
        return screen.drawables;
    }
    
    public static <T extends ClickableWidget & Drawable & Selectable> T addRenderableWidget(Screen screen, T widget) {
        try {
            return (T) ObfuscationReflectionHelper.findMethod(Screen.class, "m_142416_", Element.class).invoke(screen, widget);
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static <T extends Drawable> T addRenderableOnly(Screen screen, T listener) {
        try {
            return (T) ObfuscationReflectionHelper.findMethod(Screen.class, "m_169394_", Drawable.class).invoke(screen, listener);
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static <T extends Element & Selectable> T addWidget(Screen screen, T listener) {
        try {
            return (T) ObfuscationReflectionHelper.findMethod(Screen.class, "m_7787_", Element.class).invoke(screen, listener);
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }
}
