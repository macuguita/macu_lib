/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.event.events.common;

import dev.architectury.event.CompoundEventResult;
import dev.architectury.event.Event;
import dev.architectury.event.EventFactory;
import dev.architectury.event.EventResult;
import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public interface PlayerEvent {
    /**
     * @see PlayerJoin#join(ServerPlayerEntity)
     */
    Event<PlayerJoin> PLAYER_JOIN = EventFactory.createLoop();
    /**
     * @see PlayerQuit#quit(ServerPlayerEntity)
     */
    Event<PlayerQuit> PLAYER_QUIT = EventFactory.createLoop();
    /**
     * @see PlayerRespawn#respawn(ServerPlayerEntity, boolean, net.minecraft.entity.Entity.RemovalReason)
     */
    Event<PlayerRespawn> PLAYER_RESPAWN = EventFactory.createLoop();
    /**
     * @see PlayerAdvancement#award(ServerPlayerEntity, AdvancementEntry)
     */
    Event<PlayerAdvancement> PLAYER_ADVANCEMENT = EventFactory.createLoop();
    /**
     * @see PlayerClone#clone(ServerPlayerEntity, ServerPlayerEntity, boolean)
     */
    Event<PlayerClone> PLAYER_CLONE = EventFactory.createLoop();
    /**
     * @see CraftItem#craft(PlayerEntity, ItemStack, Inventory)
     */
    Event<CraftItem> CRAFT_ITEM = EventFactory.createLoop();
    /**
     * @see SmeltItem#smelt(PlayerEntity, ItemStack)
     */
    Event<SmeltItem> SMELT_ITEM = EventFactory.createLoop();
    /**
     * @see PickupItemPredicate#canPickup(PlayerEntity, ItemEntity, ItemStack)
     */
    Event<PickupItemPredicate> PICKUP_ITEM_PRE = EventFactory.createEventResult();
    /**
     * @see PickupItem#pickup(PlayerEntity, ItemEntity, ItemStack)
     */
    Event<PickupItem> PICKUP_ITEM_POST = EventFactory.createLoop();
    /**
     * @see ChangeDimension#change(ServerPlayerEntity, RegistryKey, RegistryKey)
     */
    Event<ChangeDimension> CHANGE_DIMENSION = EventFactory.createLoop();
    /**
     * @see DropItem#drop(PlayerEntity, ItemEntity)
     */
    Event<DropItem> DROP_ITEM = EventFactory.createEventResult();
    /**
     * @see OpenMenu#open(PlayerEntity, ScreenHandler)
     */
    Event<OpenMenu> OPEN_MENU = EventFactory.createLoop();
    /**
     * @see CloseMenu#close(PlayerEntity, ScreenHandler)
     */
    Event<CloseMenu> CLOSE_MENU = EventFactory.createLoop();
    /**
     * @see FillBucket#fill(PlayerEntity, World, ItemStack, HitResult)
     */
    Event<FillBucket> FILL_BUCKET = EventFactory.createCompoundEventResult();
    /**
     * @see AttackEntity#attack(PlayerEntity, World, Entity, Hand, EntityHitResult)
     */
    Event<AttackEntity> ATTACK_ENTITY = EventFactory.createEventResult();
    
    interface PlayerJoin {
        /**
         * Invoked after a player joined a server level.
         * Equivalent to Forge's {@code PlayerLoggedInEvent} event.
         *
         * @param player The joined player.
         */
        void join(ServerPlayerEntity player);
    }
    
    interface PlayerQuit {
        /**
         * Invoked after a player logged out of a server level.
         * Equivalent to Forge's {@code PlayerLoggedOutEvent} event.
         *
         * @param player The now logged out player.
         */
        void quit(ServerPlayerEntity player);
    }
    
    interface PlayerRespawn {
        /**
         * Invoked when a player is respawned (e.g. changing dimension).
         * Equivalent to Forge's {@code PlayerRespawnEvent} event.
         * To manipulate the player use {@link PlayerClone#clone(ServerPlayerEntity, ServerPlayerEntity, boolean)}.
         *
         * @param newPlayer    The respawned player.
         * @param conqueredEnd Whether the player has conquered the end. This is true when the player joined the end and now is leaving it. {@link ServerPlayerEntity#notInAnyWorld}
         */
        void respawn(ServerPlayerEntity newPlayer, boolean conqueredEnd, Entity.RemovalReason removalReason);
    }
    
    interface PlayerClone {
        /**
         * Invoked when a player respawns.
         * This can be used to manipulate the new player.
         * Equivalent to Forge's {@code PlayerEvent.Clone} event.
         *
         * @param oldPlayer The old player.
         * @param newPlayer The new player.
         * @param wonGame   This is true when the player joined the end and now is leaving it. {@link ServerPlayerEntity#notInAnyWorld}
         */
        void clone(ServerPlayerEntity oldPlayer, ServerPlayerEntity newPlayer, boolean wonGame);
    }
    
    interface PlayerAdvancement {
        /**
         * Invoked when a player gets an advancement.
         * Equivalent to Forge's {@code AdvancementEvent} event.
         *
         * @param player      The player who got the advancement.
         * @param advancement The advancement the player got.
         */
        void award(ServerPlayerEntity player, AdvancementEntry advancement);
    }
    
    interface CraftItem {
        /**
         * Invoked when a player crafts an item.
         * Equivalent to Forge's {@code ItemCraftedEvent} event.
         * This only applies for the vanilla crafting table (or any crafting table using the {@link net.minecraft.screen.slot.CraftingResultSlot}) and
         * the player inventory crafting grid.
         * This is invoked when the player takes something out of the result slot.
         *
         * @param player      The player.
         * @param constructed The ItemStack that has been crafted.
         * @param inventory   The inventory of the constructor.
         */
        void craft(PlayerEntity player, ItemStack constructed, Inventory inventory);
    }
    
    interface SmeltItem {
        /**
         * Invoked when a player smelts an item.
         * Equivalent to Forge's {@code ItemSmeltedEvent} event.
         * This is invoked when the player takes the stack out of the output slot.
         *
         * @param player  The player.
         * @param smelted The smelt result.
         */
        void smelt(PlayerEntity player, ItemStack smelted);
    }
    
    interface PickupItemPredicate {
        /**
         * Invoked when a player tries to pickup an {@link ItemEntity}.
         * Equivalent to Forge's {@code EntityItemPickupEvent} event.
         *
         * @param player The player picking up.
         * @param entity The {@link ItemEntity} that the player tries to pick up.
         * @param stack  The content of the {@link ItemEntity}.
         * @return A {@link EventResult} determining the outcome of the event,
         * the execution of the pickup may be cancelled by the result.
         */
        EventResult canPickup(PlayerEntity player, ItemEntity entity, ItemStack stack);
    }
    
    interface PickupItem {
        /**
         * Invoked when a player has picked up an {@link ItemEntity}.
         * Equivalent to Forge's {@code ItemPickupEvent} event.
         *
         * @param player The player.
         * @param entity The {@link ItemEntity} that the player picked up.
         * @param stack  The content of the {@link ItemEntity}.
         */
        void pickup(PlayerEntity player, ItemEntity entity, ItemStack stack);
    }
    
    interface ChangeDimension {
        /**
         * Invoked when a player changes their dimension.
         * Equivalent to Forge's {@code PlayerChangedDimensionEvent} event.
         *
         * @param player   The teleporting player.
         * @param oldLevel The level the player comes from.
         * @param newLevel The level the player teleports into.
         */
        void change(ServerPlayerEntity player, RegistryKey<World> oldLevel, RegistryKey<World> newLevel);
    }
    
    interface DropItem {
        /**
         * Invoked when a player drops an item.
         * Equivalent to Forge's {@code ItemTossEvent} event.
         *
         * @param player The player dropping something.
         * @param entity The entity that has spawned when the player dropped a ItemStack.
         * @return A {@link EventResult} determining the outcome of the event,
         * the execution of the drop may be cancelled by the result.
         */
        EventResult drop(PlayerEntity player, ItemEntity entity);
    }
    
    interface OpenMenu {
        /**
         * Invoked when a player opens a menu.
         * Equivalent to Forge's {@code PlayerContainerEvent.Open} event.
         *
         * @param player The player opening the menu.
         * @param menu   The menu that is opened.
         */
        void open(PlayerEntity player, ScreenHandler menu);
    }
    
    interface CloseMenu {
        /**
         * Invoked when a player closes a menu.
         * Equivalent to Forge's {@code PlayerContainerEvent.Close} event.
         *
         * @param player The player closing the menu.
         * @param menu   The menu that is closed.
         */
        void close(PlayerEntity player, ScreenHandler menu);
    }
    
    interface FillBucket {
        /**
         * Invoked when a player attempts to fill a bucket using right-click.
         * You can return a non-PASS interaction result to cancel further processing by other mods.
         *
         * @param player The player filling the bucket.
         * @param level  The level the player is in.
         * @param stack  The bucket stack.
         * @param target The target which the player has aimed at.
         * @return A {@link CompoundEventResult} determining the outcome of the event.
         */
        CompoundEventResult<ItemStack> fill(PlayerEntity player, World level, ItemStack stack, @Nullable HitResult target);
    }
    
    interface AttackEntity {
        /**
         * Invoked when a player is about to attack an entity using left-click.
         * Equivalent to Forge's {@code AttackEntityEvent} and Fabric API's {@code AttackEntityCallback} events.
         *
         * @param player The player attacking the entity.
         * @param level  The level the player is in.
         * @param target The entity about to be attacked.
         * @param hand   The hand the player is using.
         * @param result The entity hit result.
         * @return An {@link EventResult} determining the outcome of the event,
         * the attack may be cancelled by the result.
         */
        EventResult attack(PlayerEntity player, World level, Entity target, Hand hand, @Nullable EntityHitResult result);
    }
}
