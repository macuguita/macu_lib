package com.macuguita.lib.mixin;

import com.macuguita.lib.MacuguitaLib;
import com.macuguita.lib.supporters.RoleChecker;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Objects;

@Mixin(AbstractClientPlayerEntity.class)
public class AbstractClientPlayerEntityMixin {

    // Path to the custom cape texture in the resources folder
    @Unique
    private static final Identifier DEVELOPER_CAPE_TEXTURE = new Identifier(MacuguitaLib.MOD_ID, "textures/capes/developer_cape.png");

    @Inject(
            method = "getCapeTexture",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onGetCapeTexture(CallbackInfoReturnable<Identifier> cir) {
        // Cast 'this' to AbstractClientPlayerEntity
        AbstractClientPlayerEntity player = (AbstractClientPlayerEntity) (Object) this;

        // Check if the player has the "developer" role
        if (Objects.equals(RoleChecker.getPlayerRole(player.getUuid()), "developer")) {
            // Return the custom cape texture
            cir.setReturnValue(DEVELOPER_CAPE_TEXTURE);
        }
    }
}