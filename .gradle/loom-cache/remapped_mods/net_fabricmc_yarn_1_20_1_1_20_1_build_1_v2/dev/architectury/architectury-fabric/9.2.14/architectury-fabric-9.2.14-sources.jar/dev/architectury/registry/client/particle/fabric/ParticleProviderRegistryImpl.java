/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.registry.client.particle.fabric;

import dev.architectury.registry.client.particle.ParticleProviderRegistry;
import net.fabricmc.fabric.api.client.particle.v1.FabricSpriteProvider;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleType;
import net.minecraft.util.math.random.Random;
import java.util.List;

public class ParticleProviderRegistryImpl {
    public record ExtendedSpriteSetImpl(
            FabricSpriteProvider delegate
    ) implements ParticleProviderRegistry.ExtendedSpriteSet {
        @Override
        public SpriteAtlasTexture getAtlas() {
            return delegate.getAtlas();
        }
        
        @Override
        public List<Sprite> getSprites() {
            return delegate.getSprites();
        }
        
        @Override
        public Sprite getSprite(int i, int j) {
            return delegate.get(i, j);
        }
        
        @Override
        public Sprite getSprite(Random random) {
            return delegate.get(random);
        }
    }
    
    public static <T extends ParticleEffect> void register(ParticleType<T> type, ParticleFactory<T> provider) {
        ParticleFactoryRegistry.getInstance().register(type, provider);
    }
    
    public static <T extends ParticleEffect> void register(ParticleType<T> type, ParticleProviderRegistry.DeferredParticleProvider<T> provider) {
        ParticleFactoryRegistry.getInstance().register(type, sprites ->
                provider.create(new ExtendedSpriteSetImpl(sprites)));
    }
}
