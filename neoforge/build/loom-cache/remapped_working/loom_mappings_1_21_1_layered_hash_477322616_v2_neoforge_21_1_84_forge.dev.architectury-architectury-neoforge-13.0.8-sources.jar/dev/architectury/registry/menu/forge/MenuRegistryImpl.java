/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.registry.menu.forge;

import dev.architectury.platform.hooks.EventBusesHooks;
import dev.architectury.registry.menu.ExtendedMenuProvider;
import dev.architectury.registry.menu.MenuRegistry.ExtendedMenuTypeFactory;
import dev.architectury.registry.menu.MenuRegistry.ScreenFactory;
import dev.architectury.registry.menu.MenuRegistry.SimpleMenuTypeFactory;
import dev.architectury.utils.ArchitecturyConstants;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.ScreenHandlerProvider;
import net.minecraft.resource.featuretoggle.FeatureFlags;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

public class MenuRegistryImpl {
    public static void openExtendedMenu(ServerPlayerEntity player, ExtendedMenuProvider provider) {
        player.openMenu(provider, provider::saveExtraData);
    }
    
    @SuppressWarnings("removal")
    public static <T extends ScreenHandler> ScreenHandlerType<T> of(SimpleMenuTypeFactory<T> factory) {
        return new ScreenHandlerType<>(factory::create, FeatureFlags.VANILLA_FEATURES);
    }
    
    public static <T extends ScreenHandler> ScreenHandlerType<T> ofExtended(ExtendedMenuTypeFactory<T> factory) {
        return IMenuTypeExtension.create(factory::create);
    }
    
    @SuppressWarnings("CodeBlock2Expr") // It's neater this way
    @OnlyIn(Dist.CLIENT)
    public static <H extends ScreenHandler, S extends Screen & ScreenHandlerProvider<H>> void registerScreenFactory(ScreenHandlerType<? extends H> type, ScreenFactory<H, S> factory) {
        EventBusesHooks.whenAvailable(ArchitecturyConstants.MOD_ID, bus -> {
            bus.addListener(RegisterMenuScreensEvent.class, event -> event.register(type, factory::create));
        });
    }
}
