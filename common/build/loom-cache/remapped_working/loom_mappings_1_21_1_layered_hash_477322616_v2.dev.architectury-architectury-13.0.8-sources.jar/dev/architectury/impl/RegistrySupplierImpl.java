/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.impl;

import com.mojang.datafixers.util.Either;
import dev.architectury.registry.registries.RegistrySupplier;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryOwner;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

@ApiStatus.Internal
public interface RegistrySupplierImpl<T> extends RegistrySupplier<T> {
    @Nullable
    RegistryEntry<T> getHolder();
    
    @Override
    default T value() {
        return get();
    }
    
    @Override
    default boolean hasKeyAndValue() {
        return isPresent();
    }
    
    @Override
    default boolean matchesId(Identifier resourceLocation) {
        return getId().equals(resourceLocation);
    }
    
    @Override
    default boolean matchesKey(RegistryKey<T> resourceKey) {
        return getKey().equals(resourceKey);
    }
    
    @Override
    default boolean matches(Predicate<RegistryKey<T>> predicate) {
        return predicate.test(getKey());
    }
    
    @Override
    default boolean isIn(TagKey<T> tagKey) {
        RegistryEntry<T> holder = getHolder();
        return holder != null && holder.isIn(tagKey);
    }
    
    @Override
    default boolean matches(RegistryEntry<T> holder) {
        return holder.matchesKey(getKey());
    }
    
    @Override
    default Stream<TagKey<T>> streamTags() {
        RegistryEntry<T> holder = getHolder();
        return holder != null ? holder.streamTags() : Stream.empty();
    }
    
    @Override
    default Either<RegistryKey<T>, T> getKeyOrValue() {
        return Either.left(getKey());
    }
    
    @Override
    default Optional<RegistryKey<T>> getKey() {
        return Optional.of(getKey());
    }
    
    @Override
    default Type getType() {
        return Type.REFERENCE;
    }
    
    @Override
    default boolean ownerEquals(RegistryEntryOwner<T> holderOwner) {
        RegistryEntry<T> holder = getHolder();
        return holder != null && holder.ownerEquals(holderOwner);
    }
}
