/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.networking.forge;


import com.mojang.logging.LogUtils;
import dev.architectury.impl.NetworkAggregator;
import dev.architectury.networking.NetworkManager;
import dev.architectury.networking.NetworkManager.NetworkReceiver;
import dev.architectury.networking.SpawnEntityPacket;
import dev.architectury.platform.hooks.EventBusesHooks;
import dev.architectury.utils.ArchitecturyConstants;
import dev.architectury.utils.Env;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.common.CustomPayloadC2SPacket;
import net.minecraft.network.packet.s2c.common.CustomPayloadS2CPacket;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.EntityTrackerEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import org.slf4j.Logger;

public class NetworkManagerImpl {
    private static final Logger LOGGER = LogUtils.getLogger();
    
    public static NetworkAggregator.Adaptor getAdaptor() {
        return new NetworkAggregator.Adaptor() {
            @Override
            public <T extends CustomPayload> void registerC2S(CustomPayload.Id<T> type, PacketCodec<? super RegistryByteBuf, T> codec, NetworkReceiver<T> receiver) {
                EventBusesHooks.whenAvailable(ArchitecturyConstants.MOD_ID, bus -> {
                    bus.<RegisterPayloadHandlersEvent>addListener(event -> {
                        event.registrar(type.id().getNamespace()).optional().playToServer(type, codec, (arg, context) -> {
                            receiver.receive(arg, context(context.player(), context, false));
                        });
                    });
                });
            }
            
            @Override
            public <T extends CustomPayload> void registerS2C(CustomPayload.Id<T> type, PacketCodec<? super RegistryByteBuf, T> codec, NetworkReceiver<T> receiver) {
                EventBusesHooks.whenAvailable(ArchitecturyConstants.MOD_ID, bus -> {
                    bus.<RegisterPayloadHandlersEvent>addListener(event -> {
                        event.registrar(type.id().getNamespace()).optional().playToClient(type, codec, (arg, context) -> {
                            receiver.receive(arg, context(context.player(), context, true));
                        });
                    });
                });
            }
            
            @Override
            public <T extends CustomPayload> Packet<?> toC2SPacket(T payload) {
                return new CustomPayloadC2SPacket(payload);
            }
            
            @Override
            public <T extends CustomPayload> Packet<?> toS2CPacket(T payload) {
                return new CustomPayloadS2CPacket(payload);
            }
            
            @Override
            public <T extends CustomPayload> void registerS2CType(CustomPayload.Id<T> type, PacketCodec<? super RegistryByteBuf, T> codec) {
                registerS2C(type, codec, (payload, context) -> {
                });
            }
            
            public NetworkManager.PacketContext context(PlayerEntity player, IPayloadContext taskQueue, boolean client) {
                return new NetworkManager.PacketContext() {
                    @Override
                    public PlayerEntity getPlayer() {
                        return getEnvironment() == Env.CLIENT ? getClientPlayer() : player;
                    }
                    
                    @Override
                    public void queue(Runnable runnable) {
                        taskQueue.enqueueWork(runnable);
                    }
                    
                    @Override
                    public Env getEnvironment() {
                        return client ? Env.CLIENT : Env.SERVER;
                    }
                    
                    @Override
                    public DynamicRegistryManager registryAccess() {
                        return getEnvironment() == Env.CLIENT ? getClientRegistryAccess() : player.getRegistryManager();
                    }
                };
            }
        };
    }
    
    @OnlyIn(Dist.CLIENT)
    public static boolean canServerReceive(Identifier id) {
        if (MinecraftClient.getInstance().getNetworkHandler() != null) {
            return MinecraftClient.getInstance().getNetworkHandler().hasChannel(id);
        } else {
            return false;
        }
    }
    
    public static boolean canPlayerReceive(ServerPlayerEntity player, Identifier id) {
        return player.networkHandler.hasChannel(id);
    }
    
    public static Packet<ClientPlayPacketListener> createAddEntityPacket(Entity entity, EntityTrackerEntry serverEntity) {
        return SpawnEntityPacket.create(entity, serverEntity);
    }
    
    @OnlyIn(Dist.CLIENT)
    public static PlayerEntity getClientPlayer() {
        return MinecraftClient.getInstance().player;
    }
    
    @OnlyIn(Dist.CLIENT)
    public static DynamicRegistryManager getClientRegistryAccess() {
        if (MinecraftClient.getInstance().world != null) {
            return MinecraftClient.getInstance().world.getRegistryManager();
        } else if (MinecraftClient.getInstance().getNetworkHandler() != null) {
            return MinecraftClient.getInstance().getNetworkHandler().getRegistryManager();
        } else if (MinecraftClient.getInstance().interactionManager != null) {
            // Sometimes the packet is sent way too fast and is between the connection and the level, better safe than sorry
            return MinecraftClient.getInstance().interactionManager.networkHandler.getRegistryManager();
        }
        
        // Fail-safe
        return DynamicRegistryManager.of(Registries.REGISTRIES);
    }
}
