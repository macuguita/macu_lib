/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.mixin.fabric.client;

import com.mojang.authlib.GameProfile;
import dev.architectury.event.CompoundEventResult;
import dev.architectury.event.events.client.ClientChatEvent;
import dev.architectury.event.events.client.ClientSystemMessageEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Objects;
import net.minecraft.client.network.message.MessageHandler;
import net.minecraft.network.message.MessageType;
import net.minecraft.network.message.SignedMessage;
import net.minecraft.text.Text;

@Mixin(MessageHandler.class)
public class MixinChatListener {
    @Unique
    MessageType.Parameters boundChatType;
    @Unique
    private ThreadLocal<Text> cancelNextChat = new ThreadLocal<>();
    @Unique
    private ThreadLocal<Text> cancelNextSystem = new ThreadLocal<>();
    
    @Inject(method = "handlePlayerChatMessage", at = @At(value = "INVOKE", target = "Ljava/time/Instant;now()Ljava/time/Instant;"))
    private void handlePlayerChatMessage(SignedMessage playerChatMessage, GameProfile gameProfile, MessageType.Parameters bound, CallbackInfo ci) {
        this.boundChatType = bound;
    }
    
    @ModifyVariable(method = "handlePlayerChatMessage", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/chat/PlayerChatMessage;signature()Lnet/minecraft/network/chat/MessageSignature;"))
    private Text modifyMessage(Text value) {
        cancelNextChat.remove();
        var process = ClientChatEvent.RECEIVED.invoker().process(boundChatType, value);
        this.boundChatType = null;
        if (process.isPresent()) {
            if (process.isFalse()) {
                cancelNextChat.set(value);
            } else if (process.object() != null) {
                return process.object();
            }
        }
        
        return value;
    }
    
    @Inject(method = "handlePlayerChatMessage", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/chat/ChatListener;handleMessage(Lnet/minecraft/network/chat/MessageSignature;Ljava/util/function/BooleanSupplier;)V"),
            cancellable = true, locals = LocalCapture.CAPTURE_FAILHARD)
    private void handleChatPre(SignedMessage playerChatMessage, GameProfile gameProfile, MessageType.Parameters bound, CallbackInfo ci, boolean onlyShowSecureChat, SignedMessage filtered, Text component) {
        if (Objects.equals(cancelNextChat.get(), component)) {
            ci.cancel();
        }
        
        cancelNextChat.remove();
    }
    
    @ModifyVariable(method = "handleSystemMessage", at = @At(value = "HEAD"), argsOnly = true)
    private Text modifySystemMessage(Text message) {
        cancelNextSystem.remove();
        var process = ClientSystemMessageEvent.RECEIVED.invoker().process(message);
        if (process.isPresent()) {
            if (process.isFalse()) {
                cancelNextSystem.set(message);
            } else if (process.object() != null) {
                return process.object();
            }
        }
        return message;
    }
    
    @Inject(method = "handleSystemMessage", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Options;hideMatchedNames()Lnet/minecraft/client/OptionInstance;"),
            cancellable = true)
    private void handleSystemMessage(Text component, boolean bl, CallbackInfo ci) {
        if (Objects.equals(cancelNextSystem.get(), component)) {
            ci.cancel();
        }
        
        cancelNextSystem.remove();
    }
}
